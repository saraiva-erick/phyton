Estes são os materiais de aula do curso PySnake da Asimov Academy.

Cada script representa o estado do código após o conteúdo apresentado em cada uma das aulas.

Dessa forma, o último script ("12. Pontos e dificuldade.py") representa a versão final do Snake Game criado em aula.

Bons estudos!
